This is a project by myself and a friend who as of yet does not have a github tag [remove and replace once he does] 
If you are a more experienced developer, please do not snipe it from under us, it isn't worth the time and effort it would take to do so
Created in Unity
